import java.util.ArrayList;
public class Sorts {
	public static void main(String[] args) {
		Sorts m = new Sorts();
		String[] pool = {"abcd", "bcda", "cdba", "abc"};
		
		ArrayList<String> c = new ArrayList<String>();
		for (String s : pool)
			c.add(s);


		msort(c);

		System.out.println( c );
	}

	public static void msort(ArrayList<String> L){ 
		if (L.size() > 1) {
			// make two new arrays 1/2 size of a
			ArrayList<String> b = new ArrayList<String>();
			ArrayList<String> c = new ArrayList<String>();
			// copy a to the two arrays
			// O(n)
			copy(L, b, 0, L.size()/2);
			copy(L, c, L.size()/2, L.size());

			// msort the two arrays
			msort(b);
			msort(c);
			// ans = merge(2 arrays)
			// O(n)
			ArrayList<String> ans = merge(b,c);
			// copy the two arrays
			// O(n)
			copy(ans, L, 0, L.size());
		}
    }

    public static String name(){
        return "Chen,Eric";
    }

	public static ArrayList<String> merge(ArrayList<String> a, ArrayList<String> b) {
		int indexA = 0;
		int indexB = 0;
		int length = a.size() + b.size();
		ArrayList<String> o = new ArrayList<String>();

		for (int i = 0; i < length; i++) {
			if (indexA >= a.size()) {
				o.add(b.get(indexB));
				indexB++;
			} else if (indexB >= b.size()) {
				o.add(a.get(indexA));
				indexA++;
			} else if (a.get(indexA).compareTo(b.get(indexB)) < 0) {
				o.add(a.get(indexA));
				indexA++;
			} else {
				o.add(b.get(indexB));
				indexB++;
			}
		}
		return o;
	}
   
	public static void copy(ArrayList<String> a, ArrayList<String> target, int start, int end) {
		target.clear();
		for (int i = start; i < end; i++) {
			target.add(a.get(i));
		}
	}
}
