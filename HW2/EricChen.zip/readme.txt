steps print out backwards. First step is at the very bottom, last step at the top.
